import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
cognito = boto3.client('cognito-idp')

def cors_response(status_code, body, content_type='application/json'):
    """Helper function to return response with CORS headers"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': content_type,
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization'
        },
        'body': json.dumps(body) if isinstance(body, dict) else body
    }

def handler(event, context):
    try:
        # Debug: Print event to see structure
        print(f"Event: {json.dumps(event)}")
        
        path = event['path']
        method = event['httpMethod']
        body = event.get('body') or '{}'
        
        if method == 'POST':
            body = json.loads(body)
            if '/register' in path:
                return register(body)
            elif '/login' in path:
                return login(body)
        elif method == 'GET' and '/credits' in path:
            # For protected endpoints, API Gateway already validated the token
            # We can get user info from requestContext.authorizer.claims
            return get_credits(event)
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }

def get_credits(event):
    """Get user credits from Cognito authorizer claims"""
    try:
        # Get user info from Cognito authorizer claims
        claims = event.get('requestContext', {}).get('authorizer', {}).get('claims', {})
        print(f"Claims: {claims}")
        
        # Get user ID from claims (can be 'sub' or 'cognito:username')
        user_id = claims.get('sub') or claims.get('cognito:username')
        email = claims.get('email')
        name = claims.get('name', 'User')
        
        if not user_id:
            return cors_response(401, {'error': 'No user ID in token claims'})
        
        # Get user from DynamoDB using email
        users_table = dynamodb.Table(os.environ['USERS_TABLE'])
        if email:
            response = users_table.scan(
                FilterExpression='email = :email',
                ExpressionAttributeValues={':email': email}
            )
            
            if response['Items']:
                user = response['Items'][0]
                return cors_response(200, {
                    'userId': user['userId'],
                    'credits': int(user.get('credits', 0)),
                    'email': user.get('email', '')
                })
            else:
                # Auto-create DynamoDB record for existing Cognito user
                print(f"Creating DynamoDB record for existing user: {email}")
                users_table.put_item(
                    Item={
                        'userId': user_id,
                        'email': email,
                        'name': name,
                        'credits': 10,
                        'createdAt': datetime.now().isoformat()
                    }
                )
                return cors_response(200, {
                    'userId': user_id,
                    'credits': 10,
                    'email': email
                })
        
        # Fallback: return default credits for authenticated user
        return cors_response(200, {
            'userId': user_id,
            'credits': 10,
            'email': email or ''
        })
        
    except Exception as e:
        print(f"Error getting credits: {str(e)}")
        return cors_response(500, {'error': str(e)})

def register(data):
    try:
        print(f"Starting registration for email: {data['email']}")
        
        email = data['email']
        password = data['password']
        name = data['name']
        
        user_id = f"user_{int(datetime.now().timestamp())}"
        print(f"Generated user_id: {user_id}")
        
        # Create in Cognito
        print("Creating user in Cognito...")
        cognito.admin_create_user(
            UserPoolId=os.environ['USER_POOL_ID'],
            Username=email,
            TemporaryPassword=password,
            MessageAction='SUPPRESS'
        )
        print("User created in Cognito successfully")
        
        # Set permanent password
        print("Setting permanent password...")
        cognito.admin_set_user_password(
            UserPoolId=os.environ['USER_POOL_ID'],
            Username=email,
            Password=password,
            Permanent=True
        )
        print("Password set successfully")
        
        # Store in DynamoDB
        print("Storing user in DynamoDB...")
        table = dynamodb.Table(os.environ['USERS_TABLE'])
        table.put_item(
            Item={
                'userId': user_id,
                'email': email,
                'name': name,
                'credits': 10,
                'createdAt': datetime.now().isoformat()
            }
        )
        print("User stored in DynamoDB successfully")
        
        return {
            'statusCode': 201,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message': 'User registered', 'userId': user_id})
        }
        
    except Exception as e:
        print(f"Registration error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }

def login(data):
    email = data['email']
    password = data['password']
    
    # Authenticate with Cognito
    auth_result = cognito.admin_initiate_auth(
        UserPoolId=os.environ['USER_POOL_ID'],
        ClientId=os.environ['USER_POOL_CLIENT_ID'],
        AuthFlow='ADMIN_NO_SRP_AUTH',
        AuthParameters={
            'USERNAME': email,
            'PASSWORD': password
        }
    )
    
    # Get user from DynamoDB
    table = dynamodb.Table(os.environ['USERS_TABLE'])
    response = table.scan(
        FilterExpression='email = :email',
        ExpressionAttributeValues={':email': email}
    )
    
    user = response['Items'][0]
    
    return {
        'statusCode': 200,
        'headers': {'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({
            'token': auth_result['AuthenticationResult']['IdToken'],  # Use IdToken instead of AccessToken
            'user': {
                'userId': user['userId'],
                'email': user['email'],
                'credits': int(user['credits'])  # Convert Decimal to int
            }
        })
    }


